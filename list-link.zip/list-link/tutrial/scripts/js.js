
var add=document.getElementById("click");
add.onclick=function (){
       
       var first=document.getElementsByTagName("input")[0].value;
				var last=document.getElementsByTagName("input")[1].value;
     if(!first=="" && !last=="" && first<last){
				for (var i=first; i<=last; i++){
       document.write("<span>(&#"+i+")=("+i+")  </span>");
						}
			}
}

var defalt=document.getElementById("defalt");
defalt.onclick=function (){
       for (var i=9600; i<=10174; i++){
				document.write("<span>(&#"+i+")=("+i+")  </span>");
				}
       for (var x=11446; x<=11453; x++){
       document.write("(&#"+x+")=("+x+")  ");
				}
}


//single icon 
var inpbar=document.getElementById("inpbar");
inpbar.oninput=function() {
       var icons=document.getElementById("icons");
			icons.innerHTML=`&#${inpbar.value};`
}
var inpvar=document.getElementById("inpvar");
inpvar.oninput=function() {
       var ico=document.getElementById("ico");
			ico.innerHTML=`&${inpvar.value};`
}




//copy
handlecop=(e)=>{
		var inpbar=document.querySelector("#inpbar").value;
		if(!inpbar==""){
     		inpbar=document.querySelector("#inpbar").value;
       document.querySelector("#inpbar").value=`&#${inpbar};`;
       document.querySelector("#inpbar").select();
       document.execCommand("copy");
       document.querySelector("#text").innerHTML=`&#${inpbar};`;
			}
  }
handlecopy=(e)=>{
	 var inpvar=document.querySelector("#inpvar").value;
   if(!inpvar==""){
     		inpvar=document.querySelector("#inpvar").value;
       document.querySelector("#inpvar").value=`&${inpvar};`;
       document.querySelector("#inpvar").select();
       document.execCommand("copy");
       document.querySelector("#text").innerHTML=`&${inpvar};`;
		}
       
 }