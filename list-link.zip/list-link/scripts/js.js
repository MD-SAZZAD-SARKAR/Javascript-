

jQuery(document).ready(function(){
//only show     
jQuery('a').hide();
jQuery('.framework').fadeToggle(1000);
jQuery('.social').fadeToggle(1000);
jQuery('.tutor').fadeToggle(1000);
jQuery('.news').fadeToggle(1000);
jQuery('.seo').fadeToggle(1000);
jQuery('.devolop').fadeToggle(1000);
jQuery('news').fadeToggle(1000);

//CDN
    jQuery('.cd_n').click(function(){
    jQuery('a').hide();
    jQuery('.framework').fadeToggle(1000);
});
//SOCIAL
    jQuery('.socia_l').click(function(){
        jQuery('a').hide();
    				jQuery('.social').fadeToggle(1000);
    
    });

//TUTOR
 			jQuery(".tuto_r").click(function(){
   			 jQuery('a').hide();
    				jQuery('.tutor').fadeToggle(1000);
    
});
//NEWS
					jQuery('.new_s').click(function(){
								jQuery('a').hide();
								jQuery('.news').fadeToggle(1000);
    
});
//ALL
jQuery('.all').click(function(){
								jQuery('a').hide();
								jQuery('.framework').fadeToggle(1000);
								jQuery('.social').fadeToggle(1000);
								jQuery('.tutor').fadeToggle(1000);
								jQuery('.news').fadeToggle(1000);
								jQuery('.seo').fadeToggle(1000);
								jQuery('.devolop').fadeToggle(1000);
								jQuery('news').fadeToggle(1000);
});
//SEO
jQuery('.se_o').click(function(){
								jQuery('a').hide();
								jQuery('.seo').fadeToggle(1000);
    
});
//DEVOLVE 
jQuery('.devolo_p').click(function(){
								jQuery('a').hide();
								jQuery('.devolop').fadeToggle(1000);
    
});
jQuery('.education_b').click(function(){
								jQuery('a').hide();
								jQuery('.educationb').fadeToggle(1000);
    
});



//crent date
var count=00;
var m=00;
var h=00;
setInterval(function (){
//bar menu
    count++;
    if(count==60){
        m++
        count=0;
        
        if(m==60){
            h++;
            m=0;
            
        }
    }
    if(m>=5){
            var want="<br/>What do you want man? please contact me from menu panel."
    }else{
        var want=" ";
    }
    document.getElementsByClassName("s_time")[0].innerHTML=" your= "+h+"H : "+m+"M : "+count+"S"+want;

jQuery(".bar_a").show();
jQuery(".top_a").show();
    document.getElementsByClassName("date")[0].innerHTML=new Date().getFullYear();
},1000);
jQuery(".a").hide()
});


