var bar = document.querySelector(".bar");
var menu = document.querySelector(".menu");
var close = document.querySelector(".close");

//bar close
		close.onclick= function (){
   		 bar.style.cssText="width:0%";
		}
//bar open
		menu.onclick= function (){
   		 bar.style.cssText="width:70%";
		}
//toggle background color
 		var background = document.querySelector(".background");
			
			background.onclick=function(){
   	var back_ground = document.querySelector(".back_ground");
    	if(back_ground.style.display==="block"){
        back_ground.style.display="none";
    }else{
        back_ground.style.display="block";
    }
}

var red = document.querySelector(".red");
var gray = document.querySelector(".gray");
var skyblue = document.querySelector(".skyblue");
var green = document.querySelector(".green");
var royalblue = document.querySelector(".royalblue");
var purple = document.querySelector(".purple");

red.onclick=function (){
		document.querySelector(".bar").style.background="red";
		document.getElementsByTagName("body")[0].style.background="red";
}
gray.onclick=function (){
		document.querySelector(".bar").style.background="gray";
		
		document.getElementsByTagName("body")[0].style.background="gray";
}
red.onclick=function (){
		document.querySelector(".bar").style.background="red";
		document.getElementsByTagName("body")[0].style.background="red";
}
skyblue.onclick=function (){
	document.querySelector(".bar").style.background="skyblue";
			document.getElementsByTagName("body")[0].style.background="skyblue";
}
green.onclick=function (){
		document.querySelector(".bar").style.background="green";
		document.getElementsByTagName("body")[0].style.background="green";
}
royalblue.onclick=function (){
		document.querySelector(".bar").style.background="royalblue";
		document.getElementsByTagName("body")[0].style.background="royalblue";
}
purple.onclick=function (){
		document.querySelector(".bar").style.background="purple";
		document.getElementsByTagName("body")[0].style.background="purple";
}
		